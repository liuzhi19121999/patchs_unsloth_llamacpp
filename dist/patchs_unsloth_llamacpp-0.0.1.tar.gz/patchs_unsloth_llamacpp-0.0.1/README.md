# patch_unsloth_llamacpp

## Overview

patch_unsloth_llamacpp is a tool designed to accelerate model inference on the Windows platform using llama.cpp as its backend.

## Features

- Accelerates model inference by llama.cpp.
- Compatible with Windows operating system.
- If RAM is not enough, also support move data to VRAM ( this may consume more VRAM ).
- Only Support GRPOTrainer now.

## Usage Example

To use patch_unsloth_llamacpp, follow these steps:

1. Install the python package:

    ```bash
    python3 -m pip install patch_unsloth_llamacpp
    ```

2. Add code below in you project:

   ```python
   # use code below before import unsloth and unsloth-zoo
   from patch_unsloth_llamacpp import patch
   patch("GRPO")
   ```

3. Run your project:

   ```bash
   python3 your_project.py
   ```

4. If RAM is OOM when training, add these code below to move data to VRAM instead.
    ```python
    from patch_unsloth_llamacpp import unsloth_cpu_oom_patch
    unsloth_cpu_oom_patch(True)
    ```

## Known Issues

### 1. **First Run Error**

On the initial run, you might encounter an error stating "AttributeError: 'NoneType' object has no attribute 'span'". Simply running the application again should resolve this issue.

## Contact Author

For questions or contributions, please contact the author at [liuzhi1999@foxmail.com](mailto:liuzhi1999@foxmail.com).
