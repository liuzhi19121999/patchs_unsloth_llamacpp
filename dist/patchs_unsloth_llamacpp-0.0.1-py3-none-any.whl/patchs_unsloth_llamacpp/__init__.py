from .patch import patch
from .patch import unsloth_cpu_oom_patch
from .convert_hf_to_gguf import generate_model_for_acc